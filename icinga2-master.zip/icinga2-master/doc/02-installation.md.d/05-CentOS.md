# Install Icinga 2 on CentOS
<!-- {% set centos = True %} -->
<!-- {% include "02-installation.md" %} -->
