# Install Icinga 2 on Fedora
<!-- {% set fedora = True %} -->
<!-- {% include "02-installation.md" %} -->
