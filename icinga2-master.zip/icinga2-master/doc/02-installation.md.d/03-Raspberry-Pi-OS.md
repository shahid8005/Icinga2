# Install Icinga 2 on Raspberry Pi OS
<!-- {% set debian = True %} -->
<!-- {% include "02-installation.md" %} -->
