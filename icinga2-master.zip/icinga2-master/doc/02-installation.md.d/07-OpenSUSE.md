# Install Icinga 2 on openSUSE
<!-- {% set opensuse = True %} -->
<!-- {% include "02-installation.md" %} -->
